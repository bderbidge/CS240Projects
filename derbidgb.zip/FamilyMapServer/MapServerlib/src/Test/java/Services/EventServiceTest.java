package Services;

import org.junit.Test;



/**
 * Created by brandonderbidge on 5/31/17.
 */
public class EventServiceTest {
    @Test
    public void getEvents() throws Exception {

    }

    @Test
    public void get() throws Exception {

    }

}