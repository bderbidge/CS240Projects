package Response;

/**
 * Created by brandonderbidge on 5/20/17.
 */

public class GeneralPurposeMessage {

    /**
     * This returns any type of general purpose message to the user.
     */

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
