package FillData;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by brandonderbidge on 5/30/17.
 */

public class MaleNames {
    List<String> data = new ArrayList<>();

    public List<String> getData() {
        return data;
    }

    public void setData(ArrayList<String> data) {
        this.data = data;
    }
}
