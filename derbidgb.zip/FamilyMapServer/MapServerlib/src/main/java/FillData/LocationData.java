package FillData;

import java.util.List;

/**
 * Created by brandonderbidge on 5/30/17.
 */

public class LocationData {

    List<Location> data;

    public List<Location> getData() {
        return data;
    }

    public void setData(List<Location> data) {
        this.data = data;
    }
}
