package FillData;

import java.util.List;

/**
 * Created by brandonderbidge on 5/30/17.
 */

public class LastNames {

    List<String> data;

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
